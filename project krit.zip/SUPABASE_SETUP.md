# Connecting the Donation Form to Supabase

This explains exactly what to click in the Supabase dashboard, what to paste
where, and how to verify everything works. No code edits are needed from you
— the form, modals, animations, and styling are unchanged.

---

## 1. Run the database schema

1. Open your Supabase project → **SQL Editor** (left sidebar) → **New query**.
2. Open `supabase-schema.sql` (included in this project) and paste its entire
   contents into the editor.
3. Click **Run**.

This creates:
- A `donations` table (`donor_name`, `amount`, `screenshot_url`, `status`,
  `client_token`, `created_at`).
- A unique index on `client_token`, so the database itself blocks duplicate
  submissions even if the client retries a request.
- Row Level Security, **enabled**, with a policy that only allows public
  `INSERT` — no one can read, edit, or delete donations using the public
  website key. You'll view submissions in the Table Editor instead (see
  step 4).
- A public Storage bucket named `payment-screenshots`, with policies that
  let visitors upload a screenshot and let the resulting URL be viewed
  (needed for the public URL stored alongside each donation to work).

You only need to run this once.

---

## 2. Get your Project URL and Publishable Key

1. In Supabase: **Project Settings** (gear icon) → **API**.
2. Copy the **Project URL** (looks like `https://xxxxxxxx.supabase.co`).
3. Copy the key labeled **anon** / **public** / **publishable**
   (you already have this: `sb_publishable_rJUjaIRS6KW1rUsbpibE7A_AdaO1Ej8`).

⚠️ Only ever use the anon/publishable key in this project. Never the
`service_role` secret key — that key must never be placed in any file here
or pasted into chat, since it bypasses Row Level Security entirely.

> Since you've already shared this publishable key in our conversation: that's
> low-risk (publishable keys are designed to be public, the same way a
> website's URL is), but if you'd rather not have this exact value floating
> in chat history, you can regenerate it from **Project Settings → API →
> Reset anon key** at any time and use the new one below instead.

---

## 3. Paste your values — where exactly

You do **not** paste these into any file in this project. They go into
**Vercel's dashboard** as environment variables, which is what keeps them
out of your source code:

1. Go to your project on **vercel.com** → **Settings** → **Environment Variables**.
2. Add:
   | Name | Value |
   |---|---|
   | `SUPABASE_URL` | your Project URL from step 2 |
   | `SUPABASE_PUBLISHABLE_KEY` | your publishable key from step 2 |
3. Apply them to **Production**, **Preview**, and **Development** (check all
   three environments).
4. Redeploy (Vercel → Deployments → ⋯ → Redeploy), or just push a commit —
   either triggers the build step that injects these into the site.

### Testing locally before deploying
If you want to preview locally first:
```
cp .env.example .env
# edit .env and fill in your real values
SUPABASE_URL=... SUPABASE_PUBLISHABLE_KEY=... node build.js
```
Then open `index.html` in a browser (or serve the folder with any static
server). This regenerates `env-config.js` with your real values for local
testing only — `.env` is gitignored and never gets committed.

---

## 4. How it works (for your reference, no action needed)

- `build.js` runs automatically before every Vercel deploy (it's wired up
  via `vercel.json` and `package.json`). It reads `SUPABASE_URL` and
  `SUPABASE_PUBLISHABLE_KEY` from Vercel's environment and writes them into
  `env-config.js`, which `index.html` loads as a plain script tag.
- This is the standard pattern for getting environment variables into a
  plain static site (no framework) — `index.html` itself never contains
  your real key; it's generated fresh on every build.
- The donation form's "Confirm Donation" button now:
  1. Disables itself and shows a small spinner ("Saving…") — **loading state**.
  2. If a screenshot was attached, uploads it to the `payment-screenshots`
     bucket and gets back a public URL.
  3. Inserts one row into `donations` with the donor's name, amount, the
     screenshot URL (or `null` if none), and a one-time `client_token`.
  4. On success: closes the modal, shows the existing "Thank you" toast,
     and resets the form — **success state**.
  5. On failure (network issue, Supabase misconfigured, etc.): re-enables
     the button and shows a toast explaining something went wrong, so the
     visitor can simply try again — **error state**. Nothing is lost; the
     form keeps whatever they typed.
- **Duplicate-submission protection** is two layers deep: the button
  disables itself the instant it's clicked (so a second click does
  nothing while the first request is still in flight), and every attempt
  carries a freshly generated `client_token` that the database enforces as
  unique — so even a retried network request can't create two rows.

---

## 5. Verify a submission actually lands in the database

1. On your live (or locally built) site, open the Donate modal, fill in a
   name and amount, click **Proceed to Pay**, optionally attach a test
   image, then click **Confirm Donation**.
2. You should see the button briefly show "Saving…", then the modal closes
   and the "Thank you" toast appears.
3. In Supabase: **Table Editor → donations** — your test row should appear
   with the name, amount, a `screenshot_url` (if you attached one), and a
   timestamp.
4. If you attached a screenshot: **Storage → payment-screenshots** — the
   uploaded file should be there, named after the donation's `client_token`.
5. To confirm RLS is actually doing its job: try running
   `select * from donations;` from a fresh anonymous client (not the SQL
   editor, which runs as an admin) — it should return nothing. The SQL
   editor itself will still show rows, since it runs with elevated
   privileges; that's expected and fine.

If the toast instead shows an error message, the most common cause is the
environment variables not being set yet in Vercel (or not redeployed after
adding them) — double check step 3.
